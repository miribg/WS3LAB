package servlets;

import HTTPeXist.HTTPeXist;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class CreateCollection extends HttpServlet {

    private HTTPeXist eXist;

    public void init(ServletConfig config) {
        System.out.println("---> Entrando en init()de listResource");
        eXist = new HTTPeXist("http://localHost:8085");
        System.out.println("---> Saliendo de init()de LoginServlet");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String collection= request.getParameter("collection");

        //HTTPeXist eXist = new HTTPeXist("http://localHost:8085");
        int status = eXist.create(collection);
        status = eXist.subirString(collection, "irudia", "irudia.txt");

        request.setAttribute("collection",collection);
        String imagenURI = "http://localhost:8085/exist/rest/db/" + collection + "/";
        request.setAttribute("imagenURI",imagenURI);

        System.out.println("     Redireccionando a index.jsp");
        RequestDispatcher rd = request.getRequestDispatcher("/jsp/index.jsp");
        rd.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
