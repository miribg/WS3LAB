package servlets;

import HTTPeXist.HTTPeXist;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class NewImage extends HttpServlet {

    private HTTPeXist eXist;

    public void init(ServletConfig config) {
        System.out.println("---> Entrando en init()de listResource");
        eXist = new HTTPeXist("http://localHost:8085"); //8085: DBexits eta 8081:Tomcat
        System.out.println("---> Saliendo de init()de LoginServlet");
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String collection= request.getParameter("collection");
        String svgName = request.getParameter("svgName");
        String imagenURI = "http://localhost:8085/exist/rest/db/" + collection + "/" + svgName + "/";

        int status=eXist.subir(collection,svgName);

        request.setAttribute("collection",collection);
        request.setAttribute("svgName",svgName);
        request.setAttribute("imagenURI", imagenURI);

        System.out.println("     Redireccionando a imagenEdit.jsp");
        RequestDispatcher rd = request.getRequestDispatcher("/jsp/imagenEdit.jsp");
        rd.forward(request, response);
    }


    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request, response);
    }
}
